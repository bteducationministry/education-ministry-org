<?php
/**
 * Template Name: Funnel — Sign Up (Offer 0)
 * Slug: signup
 *
 * Registration form for the Young Civic Engagement Challenge.
 * Uses a custom form (WPForms shortcode if available, else native fallback).
 *
 * @package BT_Education_Ministry
 */

get_header();
?>

<!-- Progress Indicator -->
<div class="funnel-progress" role="navigation" aria-label="Funnel progress">
    <div class="container">
        <ol class="funnel-progress__steps">
            <li class="funnel-progress__step is-done"><span>✓</span> Discover</li>
            <li class="funnel-progress__step is-done"><span>✓</span> Learn</li>
            <li class="funnel-progress__step is-active" aria-current="step"><span>3</span> Sign Up</li>
            <li class="funnel-progress__step"><span>4</span> Welcome</li>
        </ol>
    </div>
</div>

<!-- ============================
     HERO
     ============================ -->
<section class="hero hero--page" style="min-height:300px;" aria-labelledby="signup-hero-heading">
    <div class="container">
        <div class="hero__content">
            <span class="hero__subtitle">Almost There</span>
            <h1 id="signup-hero-heading" class="hero__title">Create Your Free Account</h1>
            <p class="hero__text" style="margin-left:auto;margin-right:auto;">Fill out the short form below to join the Young Civic Engagement Challenge. It takes less than 2 minutes.</p>
        </div>
    </div>
</section>

<!-- ============================
     REGISTRATION FORM
     ============================ -->
<section class="section" aria-labelledby="signup-form-heading">
    <div class="container container--narrow">

        <div class="funnel-form-wrapper" data-aemp-form="offer0_signup">
            <h2 id="signup-form-heading" class="text-center" style="margin-bottom:var(--space-lg);">Join the Challenge</h2>

            <?php
            // Use WPForms if available (Form ID stored in theme option or hardcoded)
            $wpforms_offer0_id = get_option( 'btem_wpforms_offer0_id', '' );
            if ( $wpforms_offer0_id && shortcode_exists( 'wpforms' ) ) :
            ?>
                <?php echo do_shortcode( '[wpforms id="' . intval( $wpforms_offer0_id ) . '"]' ); ?>
            <?php else : ?>
                <!-- Native fallback form -->
                <form id="btem-offer0-signup" class="btem-form" method="post" action="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" novalidate>
                    <?php wp_nonce_field( 'btem_offer0_signup', 'btem_offer0_nonce' ); ?>
                    <input type="hidden" name="action" value="btem_offer0_signup">

                    <div class="form-group">
                        <label for="btem-fullname">Full Name <span class="required" aria-hidden="true">*</span></label>
                        <input type="text" id="btem-fullname" name="fullname" class="form-control" required aria-required="true" placeholder="Your full name">
                    </div>

                    <div class="form-group">
                        <label for="btem-email">Email Address <span class="required" aria-hidden="true">*</span></label>
                        <input type="email" id="btem-email" name="email" class="form-control" required aria-required="true" placeholder="you@example.com">
                    </div>

                    <div class="form-group">
                        <label for="btem-phone">Phone <span style="font-weight:400;color:var(--color-text-secondary);">(optional)</span></label>
                        <input type="tel" id="btem-phone" name="phone" class="form-control" placeholder="(555) 123-4567">
                    </div>

                    <div class="form-group">
                        <label for="btem-referral">How did you hear about us?</label>
                        <select id="btem-referral" name="referral" class="form-control">
                            <option value="">— Select —</option>
                            <option value="social_media">Social Media</option>
                            <option value="friend_family">Friend or Family</option>
                            <option value="church_ministry">Church / Ministry</option>
                            <option value="search_engine">Search Engine</option>
                            <option value="community_event">Community Event</option>
                            <option value="other">Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="funnel-checkbox">
                            <input type="checkbox" name="agree_terms" value="1" required aria-required="true">
                            <span>I agree to the <a href="<?php echo esc_url( home_url( '/terms/' ) ); ?>" target="_blank" rel="noopener">Terms of Service</a> and <a href="<?php echo esc_url( home_url( '/privacy/' ) ); ?>" target="_blank" rel="noopener">Privacy Policy</a>.</span>
                        </label>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn--primary btn--lg btn--full" data-aemp-cta="join_the_challenge">Join the Challenge</button>
                    </div>

                    <div id="btem-signup-message" class="funnel-form-message" role="alert" aria-live="polite"></div>
                </form>
            <?php endif; ?>

            <p class="text-center" style="margin-top:var(--space-lg);font-size:var(--text-body-sm);color:var(--color-text-secondary);">
                🔒 Your information is secure. We never share your data with third parties.
            </p>
        </div>

    </div>
</section>

<!-- ============================
     NAVIGATION
     ============================ -->
<section class="section section--light">
    <div class="container text-center">
        <a href="<?php echo esc_url( home_url( '/learn/' ) ); ?>" class="btn btn--outline">← Back to Program Details</a>
    </div>
</section>

<?php get_footer(); ?>
