<?php
/**
 * Template Name: Funnel — Learn (Offer 0)
 * Slug: learn
 *
 * Detailed curriculum breakdown, timeline, learning outcomes,
 * success stories, requirements, and CTA to signup.
 *
 * @package BT_Education_Ministry
 */

get_header();
?>

<!-- Progress Indicator -->
<div class="funnel-progress" role="navigation" aria-label="Funnel progress">
    <div class="container">
        <ol class="funnel-progress__steps">
            <li class="funnel-progress__step is-done"><span>✓</span> Discover</li>
            <li class="funnel-progress__step is-active" aria-current="step"><span>2</span> Learn</li>
            <li class="funnel-progress__step"><span>3</span> Sign Up</li>
            <li class="funnel-progress__step"><span>4</span> Welcome</li>
        </ol>
    </div>
</div>

<!-- ============================
     HERO
     ============================ -->
<section class="hero hero--page" aria-labelledby="learn-hero-heading">
    <div class="container">
        <div class="hero__content">
            <span class="hero__subtitle">Program Details</span>
            <h1 id="learn-hero-heading" class="hero__title">What You'll Learn &amp; How It Works</h1>
            <p class="hero__text" style="margin-left:auto;margin-right:auto;">A comprehensive look at the curriculum, timeline, and outcomes of the Young Civic Engagement Challenge.</p>
        </div>
    </div>
</section>

<!-- ============================
     CURRICULUM BREAKDOWN
     ============================ -->
<section class="section" aria-labelledby="curriculum-heading">
    <div class="container">
        <div class="section__header">
            <span class="section__subtitle">Curriculum</span>
            <h2 id="curriculum-heading">Detailed Curriculum Breakdown</h2>
        </div>

        <div class="grid grid--2">
            <!-- Module 1 -->
            <div class="card">
                <span class="card__tag">Module 1</span>
                <h4 class="card__title">Foundations of Civic Literacy</h4>
                <p class="card__text">Understand the structure of government, the Constitution, and your rights and responsibilities as a citizen.</p>
                <ul class="funnel-checklist">
                    <li>Three branches of government</li>
                    <li>Constitutional amendments that matter</li>
                    <li>Local vs. federal governance</li>
                    <li>Your rights in action</li>
                </ul>
            </div>

            <!-- Module 2 -->
            <div class="card">
                <span class="card__tag">Module 2</span>
                <h4 class="card__title">Financial Stewardship</h4>
                <p class="card__text">Learn the basics of budgeting, saving, credit, and building a financial foundation for your household.</p>
                <ul class="funnel-checklist">
                    <li>Personal budgeting frameworks</li>
                    <li>Understanding credit and debt</li>
                    <li>Savings strategies</li>
                    <li>Introduction to generational wealth</li>
                </ul>
            </div>

            <!-- Module 3 -->
            <div class="card">
                <span class="card__tag">Module 3</span>
                <h4 class="card__title">Community Leadership</h4>
                <p class="card__text">Develop practical skills in organizing, communication, and leading community-level initiatives.</p>
                <ul class="funnel-checklist">
                    <li>Leadership principles</li>
                    <li>Community organizing basics</li>
                    <li>Public speaking and advocacy</li>
                    <li>Project planning</li>
                </ul>
            </div>

            <!-- Module 4 -->
            <div class="card">
                <span class="card__tag">Module 4</span>
                <h4 class="card__title">Scripture-Based Ethics &amp; Service</h4>
                <p class="card__text">Ground your leadership in faith-based principles of integrity, stewardship, and service to others.</p>
                <ul class="funnel-checklist">
                    <li>Stewardship in scripture</li>
                    <li>Ethical decision-making</li>
                    <li>Service-oriented leadership</li>
                    <li>Building a personal mission</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- ============================
     TIMELINE & MILESTONES
     ============================ -->
<section class="section section--light" aria-labelledby="timeline-heading">
    <div class="container">
        <div class="section__header">
            <span class="section__subtitle">Timeline</span>
            <h2 id="timeline-heading">Program Timeline &amp; Milestones</h2>
            <p>The program is self-paced. Most participants complete it in 4–8 weeks.</p>
        </div>

        <div class="funnel-timeline funnel-timeline--horizontal">
            <div class="funnel-timeline__item">
                <div class="funnel-timeline__marker">W1</div>
                <div>
                    <h5>Week 1–2</h5>
                    <p>Onboarding &amp; Module 1: Civic Literacy foundations</p>
                </div>
            </div>
            <div class="funnel-timeline__item">
                <div class="funnel-timeline__marker">W3</div>
                <div>
                    <h5>Week 3–4</h5>
                    <p>Module 2: Financial Stewardship basics</p>
                </div>
            </div>
            <div class="funnel-timeline__item">
                <div class="funnel-timeline__marker">W5</div>
                <div>
                    <h5>Week 5–6</h5>
                    <p>Module 3: Community Leadership projects</p>
                </div>
            </div>
            <div class="funnel-timeline__item">
                <div class="funnel-timeline__marker">W7</div>
                <div>
                    <h5>Week 7–8</h5>
                    <p>Module 4: Ethics &amp; Service — Challenge completion</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ============================
     LEARNING OUTCOMES
     ============================ -->
<section class="section" aria-labelledby="outcomes-heading">
    <div class="container">
        <div class="section__header">
            <span class="section__subtitle">Outcomes</span>
            <h2 id="outcomes-heading">What You'll Walk Away With</h2>
        </div>

        <div class="grid grid--3">
            <div class="card card--program">
                <div class="card__icon">🎯</div>
                <h4 class="card__title">Practical Knowledge</h4>
                <p class="card__text">Understand how civic, legal, and financial systems work and how to navigate them.</p>
            </div>
            <div class="card card--program">
                <div class="card__icon">📋</div>
                <h4 class="card__title">Completion Certificate</h4>
                <p class="card__text">Earn a certificate of completion recognized within the BT Education Ministry network.</p>
            </div>
            <div class="card card--program">
                <div class="card__icon">🚀</div>
                <h4 class="card__title">Pathway to Advancement</h4>
                <p class="card__text">Qualified graduates can advance to Operator-level membership and deeper programs.</p>
            </div>
        </div>
    </div>
</section>

<!-- ============================
     SUCCESS STORIES
     ============================ -->
<?php get_template_part( 'template-parts/content', 'testimonials' ); ?>

<!-- ============================
     REQUIREMENTS
     ============================ -->
<section class="section" aria-labelledby="requirements-heading">
    <div class="container container--narrow">
        <div class="section__header">
            <span class="section__subtitle">Before You Start</span>
            <h2 id="requirements-heading">Requirements &amp; Expectations</h2>
        </div>

        <div class="card" style="max-width:700px;margin:0 auto;">
            <ul class="funnel-checklist funnel-checklist--lg">
                <li>Must be 16 years or older (or have parental consent)</li>
                <li>Access to a computer or smartphone with internet</li>
                <li>Commitment to complete self-paced modules</li>
                <li>Willingness to participate in community projects</li>
                <li>Agree to the ministry's code of conduct</li>
            </ul>
            <p style="margin-top:var(--space-lg);font-size:var(--text-body-sm);color:var(--color-text-secondary);">No prior experience or education level required. This program meets you where you are.</p>
        </div>
    </div>
</section>

<!-- ============================
     FINAL CTA
     ============================ -->
<section class="section section--dark" aria-labelledby="learn-final-cta">
    <div class="container text-center">
        <h2 id="learn-final-cta" style="color:var(--color-white);">Ready to Start?</h2>
        <p style="color:rgba(255,255,255,0.8);font-size:var(--text-body-lg);max-width:600px;margin:0 auto var(--space-xl);">You've seen the curriculum and what's possible. Now create your free account and begin.</p>
        <div class="btn-group" style="justify-content:center;">
            <a href="<?php echo esc_url( home_url( '/signup/' ) ); ?>" class="btn btn--primary btn--lg" data-aemp-cta="ready_to_start">Ready to Start</a>
            <a href="<?php echo esc_url( home_url( '/start/' ) ); ?>" class="btn btn--outline-light btn--lg">← Back to Overview</a>
        </div>
    </div>
</section>

<?php get_footer(); ?>
