<?php
/**
 * Template Name: Funnel — Apply (Capstone)
 * Slug: apply
 *
 * Qualification application form for the Estate Trust Directive ($55k).
 * WPForms or native fallback with client-side qualification logic.
 *
 * @package BT_Education_Ministry
 */

get_header();
?>

<!-- ============================
     HERO
     ============================ -->
<section class="hero hero--page" style="min-height:300px;" aria-labelledby="apply-hero-heading">
    <div class="container">
        <div class="hero__content">
            <span class="hero__subtitle">Capstone Application</span>
            <h1 id="apply-hero-heading" class="hero__title">Apply for the Estate Trust Directive</h1>
            <p class="hero__text" style="margin-left:auto;margin-right:auto;">Complete the qualification application below. We’ll review your information and follow up within 3–5 business days.</p>
        </div>
    </div>
</section>

<!-- ============================
     APPLICATION FORM
     ============================ -->
<section class="section" aria-labelledby="apply-form-heading">
    <div class="container container--narrow">

        <div class="funnel-form-wrapper" data-aemp-form="capstone_application">
            <h2 id="apply-form-heading" class="text-center" style="margin-bottom:var(--space-lg);">Qualification Application</h2>

            <?php
            $wpforms_capstone_id = get_option( 'btem_wpforms_capstone_id', '' );
            if ( $wpforms_capstone_id && shortcode_exists( 'wpforms' ) ) :
            ?>
                <?php echo do_shortcode( '[wpforms id="' . intval( $wpforms_capstone_id ) . '"]' ); ?>
            <?php else : ?>
                <!-- Native fallback form -->
                <form id="btem-capstone-apply" class="btem-form" method="post" action="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" novalidate>
                    <?php wp_nonce_field( 'btem_capstone_apply', 'btem_capstone_nonce' ); ?>
                    <input type="hidden" name="action" value="btem_capstone_apply">

                    <!-- Personal Information -->
                    <fieldset class="funnel-fieldset">
                        <legend>Personal Information</legend>

                        <div class="grid grid--2">
                            <div class="form-group">
                                <label for="cap-fullname">Full Name <span class="required">*</span></label>
                                <input type="text" id="cap-fullname" name="fullname" class="form-control" required aria-required="true" placeholder="Your full name">
                            </div>
                            <div class="form-group">
                                <label for="cap-email">Email Address <span class="required">*</span></label>
                                <input type="email" id="cap-email" name="email" class="form-control" required aria-required="true" placeholder="you@example.com">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="cap-phone">Phone Number <span class="required">*</span></label>
                            <input type="tel" id="cap-phone" name="phone" class="form-control" required aria-required="true" placeholder="(555) 123-4567">
                        </div>
                    </fieldset>

                    <!-- Family Structure -->
                    <fieldset class="funnel-fieldset">
                        <legend>Family Structure</legend>

                        <div class="grid grid--2">
                            <div class="form-group">
                                <label for="cap-beneficiaries">Number of Beneficiaries <span class="required">*</span></label>
                                <select id="cap-beneficiaries" name="beneficiaries" class="form-control" required aria-required="true">
                                    <option value="">— Select —</option>
                                    <option value="1-2">1–2</option>
                                    <option value="3-5">3–5</option>
                                    <option value="6-10">6–10</option>
                                    <option value="10+">10+</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="cap-generations">Generations to Cover <span class="required">*</span></label>
                                <select id="cap-generations" name="generations" class="form-control" required aria-required="true">
                                    <option value="">— Select —</option>
                                    <option value="2">2 generations</option>
                                    <option value="3">3 generations</option>
                                    <option value="4+">4+ generations</option>
                                </select>
                            </div>
                        </div>
                    </fieldset>

                    <!-- Asset Overview -->
                    <fieldset class="funnel-fieldset">
                        <legend>Asset Overview</legend>

                        <div class="form-group">
                            <label for="cap-assets">Estimated Total Assets <span class="required">*</span></label>
                            <select id="cap-assets" name="total_assets" class="form-control" required aria-required="true">
                                <option value="">— Select Range —</option>
                                <option value="under-250k">Under $250,000</option>
                                <option value="250k-500k">$250,000 – $500,000</option>
                                <option value="500k-1m">$500,000 – $1,000,000</option>
                                <option value="1m-5m">$1,000,000 – $5,000,000</option>
                                <option value="5m+">$5,000,000+</option>
                            </select>
                        </div>
                    </fieldset>

                    <!-- Planning Status -->
                    <fieldset class="funnel-fieldset">
                        <legend>Current Planning Status</legend>

                        <div class="form-group">
                            <label for="cap-estate-status">Current Estate Planning Status <span class="required">*</span></label>
                            <select id="cap-estate-status" name="estate_status" class="form-control" required aria-required="true">
                                <option value="">— Select —</option>
                                <option value="none">No estate plan in place</option>
                                <option value="basic-will">Basic will only</option>
                                <option value="simple-trust">Simple trust established</option>
                                <option value="complex-existing">Complex trust(s) already in place</option>
                                <option value="needs-update">Existing plan needs updating</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="cap-governance">Governance Experience</label>
                            <select id="cap-governance" name="governance_experience" class="form-control">
                                <option value="">— Select —</option>
                                <option value="none">None</option>
                                <option value="some">Some familiarity</option>
                                <option value="experienced">Experienced (board, trustee, etc.)</option>
                                <option value="btem-member">Current BTEM Member (Operator+)</option>
                            </select>
                        </div>
                    </fieldset>

                    <!-- Interest & Timeline -->
                    <fieldset class="funnel-fieldset">
                        <legend>Interest &amp; Timeline</legend>

                        <div class="form-group">
                            <label for="cap-interest">Why are you interested in the Estate Trust Directive? <span class="required">*</span></label>
                            <textarea id="cap-interest" name="interest_reason" class="form-control" rows="4" required aria-required="true" placeholder="Tell us about your goals and what prompted your interest…"></textarea>
                        </div>

                        <div class="form-group">
                            <label for="cap-timeframe">Preferred Consultation Timeframe</label>
                            <select id="cap-timeframe" name="timeframe" class="form-control">
                                <option value="">— Select —</option>
                                <option value="asap">As soon as possible</option>
                                <option value="1-2-weeks">Within 1–2 weeks</option>
                                <option value="1-month">Within 1 month</option>
                                <option value="flexible">Flexible / No rush</option>
                            </select>
                        </div>
                    </fieldset>

                    <div class="form-group">
                        <button type="submit" class="btn btn--primary btn--lg btn--full" data-aemp-cta="submit_capstone_application">Submit Application</button>
                    </div>

                    <div id="btem-capstone-message" class="funnel-form-message" role="alert" aria-live="polite"></div>
                </form>
            <?php endif; ?>

            <p class="text-center" style="margin-top:var(--space-lg);font-size:var(--text-body-sm);color:var(--color-text-secondary);">
                🔒 Your information is confidential and will only be reviewed by our Capstone advisory team.
            </p>
        </div>

    </div>
</section>

<!-- ============================
     NAVIGATION
     ============================ -->
<section class="section section--light">
    <div class="container text-center">
        <a href="<?php echo esc_url( home_url( '/capstone/' ) ); ?>" class="btn btn--outline">← Back to Capstone Overview</a>
    </div>
</section>

<?php get_footer(); ?>
