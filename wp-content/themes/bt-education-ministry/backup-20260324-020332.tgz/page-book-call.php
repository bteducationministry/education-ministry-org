<?php
/**
 * Template Name: Funnel — Book Call (Capstone)
 * Slug: book-call
 *
 * Consultation booking interface for qualified Capstone applicants.
 * Embeds Calendly if configured, otherwise provides a simple booking form.
 *
 * @package BT_Education_Ministry
 */

get_header();
?>

<!-- ============================
     HERO
     ============================ -->
<section class="hero hero--page" style="min-height:300px;" aria-labelledby="book-hero-heading">
    <div class="container">
        <div class="hero__content">
            <span class="hero__subtitle">Schedule Your Consultation</span>
            <h1 id="book-hero-heading" class="hero__title">Book Your Capstone Consultation</h1>
            <p class="hero__text" style="margin-left:auto;margin-right:auto;">You’ve been qualified for the Estate Trust Directive. Schedule your complimentary consultation to discuss your family’s needs.</p>
        </div>
    </div>
</section>

<!-- ============================
     BOOKING INTERFACE
     ============================ -->
<section class="section" aria-labelledby="booking-heading">
    <div class="container container--narrow">
        <h2 id="booking-heading" class="text-center" style="margin-bottom:var(--space-xl);">Schedule Your Consultation</h2>

        <?php
        $calendly_url = get_option( 'btem_calendly_url', '' );
        if ( $calendly_url ) :
        ?>
            <!-- Calendly Embed -->
            <div class="funnel-calendly-embed">
                <div class="calendly-inline-widget" data-url="<?php echo esc_url( $calendly_url ); ?>" style="min-width:320px;height:700px;"></div>
                <script type="text/javascript" src="https://assets.calendly.com/assets/external/widget.js" async></script>
            </div>
        <?php else : ?>
            <!-- Booking Request Form -->
            <div class="funnel-form-wrapper" data-aemp-form="booking_request">
                <?php
                $wpforms_booking_id = get_option( 'btem_wpforms_booking_id', '' );
                if ( $wpforms_booking_id && shortcode_exists( 'wpforms' ) ) :
                ?>
                    <?php echo do_shortcode( '[wpforms id="' . intval( $wpforms_booking_id ) . '"]' ); ?>
                <?php else : ?>
                    <form id="btem-book-call" class="btem-form" method="post" action="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" novalidate>
                        <?php wp_nonce_field( 'btem_book_call', 'btem_booking_nonce' ); ?>
                        <input type="hidden" name="action" value="btem_book_call">

                        <div class="grid grid--2">
                            <div class="form-group">
                                <label for="book-fullname">Full Name <span class="required">*</span></label>
                                <input type="text" id="book-fullname" name="fullname" class="form-control" required aria-required="true">
                            </div>
                            <div class="form-group">
                                <label for="book-email">Email <span class="required">*</span></label>
                                <input type="email" id="book-email" name="email" class="form-control" required aria-required="true">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="book-phone">Phone Number <span class="required">*</span></label>
                            <input type="tel" id="book-phone" name="phone" class="form-control" required aria-required="true">
                        </div>

                        <div class="grid grid--2">
                            <div class="form-group">
                                <label for="book-date1">Preferred Date (Option 1) <span class="required">*</span></label>
                                <input type="date" id="book-date1" name="preferred_date_1" class="form-control" required aria-required="true">
                            </div>
                            <div class="form-group">
                                <label for="book-time1">Preferred Time</label>
                                <select id="book-time1" name="preferred_time_1" class="form-control">
                                    <option value="morning">Morning (9am – 12pm)</option>
                                    <option value="afternoon">Afternoon (12pm – 4pm)</option>
                                    <option value="evening">Evening (4pm – 7pm)</option>
                                </select>
                            </div>
                        </div>

                        <div class="grid grid--2">
                            <div class="form-group">
                                <label for="book-date2">Preferred Date (Option 2)</label>
                                <input type="date" id="book-date2" name="preferred_date_2" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="book-time2">Preferred Time</label>
                                <select id="book-time2" name="preferred_time_2" class="form-control">
                                    <option value="morning">Morning (9am – 12pm)</option>
                                    <option value="afternoon">Afternoon (12pm – 4pm)</option>
                                    <option value="evening">Evening (4pm – 7pm)</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="book-notes">Additional Notes</label>
                            <textarea id="book-notes" name="notes" class="form-control" rows="3" placeholder="Any specific topics you’d like to discuss or questions you have…"></textarea>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn--primary btn--lg btn--full" data-aemp-cta="schedule_consultation">Submit Booking Request</button>
                        </div>

                        <div id="btem-booking-message" class="funnel-form-message" role="alert" aria-live="polite"></div>
                    </form>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- ============================
     WHAT TO EXPECT
     ============================ -->
<section class="section section--light" aria-labelledby="expect-heading">
    <div class="container container--narrow">
        <div class="section__header">
            <span class="section__subtitle">Preparation</span>
            <h2 id="expect-heading">What to Expect in Your Consultation</h2>
        </div>

        <div class="grid grid--2">
            <div class="card">
                <h4 class="card__title">During the Call</h4>
                <ul class="funnel-checklist">
                    <li>Review of your family structure and goals</li>
                    <li>Discussion of asset overview and planning needs</li>
                    <li>Walkthrough of the Estate Trust Directive process</li>
                    <li>Q&amp;A with our advisory team</li>
                    <li>Timeline and next-steps discussion</li>
                </ul>
            </div>
            <div class="card">
                <h4 class="card__title">Preparation Checklist</h4>
                <ul class="funnel-checklist">
                    <li>List of all family members / beneficiaries</li>
                    <li>Summary of major assets (real estate, accounts, business)</li>
                    <li>Any existing estate planning documents</li>
                    <li>Key questions or concerns about trust structuring</li>
                    <li>Quiet space with 60 minutes available</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- ============================
     CONTACT INFO
     ============================ -->
<section class="section" aria-labelledby="contact-heading">
    <div class="container container--narrow text-center">
        <h2 id="contact-heading">Questions Before Booking?</h2>
        <p style="font-size:var(--text-body-lg);max-width:600px;margin:0 auto var(--space-xl);">Our Capstone advisory team is available to answer any questions before your consultation.</p>
        <div class="grid grid--3">
            <div>
                <h5>📧 Email</h5>
                <p><a href="mailto:capstone@educationministry.org">capstone@educationministry.org</a></p>
            </div>
            <div>
                <h5>📞 Phone</h5>
                <p><a href="tel:+17323759474">(732) 375-9474</a></p>
            </div>
            <div>
                <h5>📍 Office</h5>
                <p>971 US Highway 202 N, Ste N<br>Branchburg, NJ 08876</p>
            </div>
        </div>
    </div>
</section>

<!-- ============================
     NAVIGATION
     ============================ -->
<section class="section section--dark">
    <div class="container text-center">
        <a href="<?php echo esc_url( home_url( '/capstone/' ) ); ?>" class="btn btn--outline-light">← Back to Capstone Overview</a>
    </div>
</section>

<?php get_footer(); ?>
