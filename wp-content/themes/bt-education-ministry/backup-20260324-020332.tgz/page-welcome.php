<?php
/**
 * Template Name: Funnel — Welcome (Offer 0)
 * Slug: welcome
 *
 * Post-registration confirmation page.
 * Auto-redirects to platform.btpma.org/educate/ after 5 seconds.
 *
 * @package BT_Education_Ministry
 */

get_header();
?>

<!-- Progress Indicator -->
<div class="funnel-progress" role="navigation" aria-label="Funnel progress">
    <div class="container">
        <ol class="funnel-progress__steps">
            <li class="funnel-progress__step is-done"><span>✓</span> Discover</li>
            <li class="funnel-progress__step is-done"><span>✓</span> Learn</li>
            <li class="funnel-progress__step is-done"><span>✓</span> Sign Up</li>
            <li class="funnel-progress__step is-active" aria-current="step"><span>✓</span> Welcome</li>
        </ol>
    </div>
</div>

<!-- ============================
     WELCOME HERO
     ============================ -->
<section class="hero hero--page" style="min-height:350px;" aria-labelledby="welcome-heading">
    <div class="container">
        <div class="hero__content">
            <div style="font-size:64px;margin-bottom:var(--space-md);">🎉</div>
            <h1 id="welcome-heading" class="hero__title">Congratulations!</h1>
            <p class="hero__text" style="margin-left:auto;margin-right:auto;">You're officially part of the Young Civic Engagement Challenge. Your journey toward civic literacy and community leadership starts now.</p>
        </div>
    </div>
</section>

<!-- ============================
     WHAT HAPPENS NEXT
     ============================ -->
<section class="section" aria-labelledby="next-steps-heading">
    <div class="container container--narrow">
        <div class="section__header">
            <span class="section__subtitle">Next Steps</span>
            <h2 id="next-steps-heading">What Happens Next</h2>
        </div>

        <div class="funnel-timeline">
            <div class="funnel-timeline__item">
                <div class="funnel-timeline__marker">📧</div>
                <div>
                    <h5>Check Your Email</h5>
                    <p>A welcome email with your login credentials has been sent. Check your spam folder if you don't see it within a few minutes.</p>
                </div>
            </div>
            <div class="funnel-timeline__item">
                <div class="funnel-timeline__marker">🔐</div>
                <div>
                    <h5>Access the Learning Platform</h5>
                    <p>Log in to <a href="https://platform.btpma.org/educate/" target="_blank" rel="noopener">platform.btpma.org/educate/</a> using the credentials from your welcome email.</p>
                </div>
            </div>
            <div class="funnel-timeline__item">
                <div class="funnel-timeline__marker">📚</div>
                <div>
                    <h5>Start Module 1</h5>
                    <p>Begin with "Foundations of Civic Literacy" — your first step toward understanding the systems that shape your community.</p>
                </div>
            </div>
            <div class="funnel-timeline__item">
                <div class="funnel-timeline__marker">🏆</div>
                <div>
                    <h5>Complete the Challenge</h5>
                    <p>Work through all 4 modules at your own pace. Earn your certificate and unlock advancement opportunities.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ============================
     QUICK START GUIDE
     ============================ -->
<section class="section section--light" aria-labelledby="quickstart-heading">
    <div class="container container--narrow">
        <div class="section__header">
            <span class="section__subtitle">Quick Start</span>
            <h2 id="quickstart-heading">Get Started in 3 Steps</h2>
        </div>

        <div class="grid grid--3">
            <div class="card text-center">
                <div style="font-size:36px;margin-bottom:var(--space-sm);">1️⃣</div>
                <h4 class="card__title">Open Your Email</h4>
                <p class="card__text">Find your welcome message with login details.</p>
            </div>
            <div class="card text-center">
                <div style="font-size:36px;margin-bottom:var(--space-sm);">2️⃣</div>
                <h4 class="card__title">Log In</h4>
                <p class="card__text">Visit the secure learning platform and sign in.</p>
            </div>
            <div class="card text-center">
                <div style="font-size:36px;margin-bottom:var(--space-sm);">3️⃣</div>
                <h4 class="card__title">Begin Learning</h4>
                <p class="card__text">Start Module 1 and track your progress.</p>
            </div>
        </div>
    </div>
</section>

<!-- ============================
     AUTO-REDIRECT + MANUAL LINK
     ============================ -->
<section class="section section--dark" aria-labelledby="redirect-heading">
    <div class="container text-center">
        <h2 id="redirect-heading" style="color:var(--color-white);">Redirecting You to the Dashboard…</h2>
        <p style="color:rgba(255,255,255,0.8);font-size:var(--text-body-lg);max-width:600px;margin:0 auto var(--space-md);">You will be automatically redirected in <span id="btem-countdown" style="color:var(--color-gold);font-weight:700;">5</span> seconds.</p>
        <a href="https://platform.btpma.org/educate/" class="btn btn--primary btn--lg" target="_blank" rel="noopener" data-aemp-cta="access_dashboard">Access Your Dashboard</a>
        <p style="margin-top:var(--space-md);font-size:var(--text-body-sm);color:rgba(255,255,255,0.6);">If you are not redirected, click the button above.</p>
    </div>
</section>

<script>
(function(){
    var seconds = 5;
    var el = document.getElementById('btem-countdown');
    var timer = setInterval(function(){
        seconds--;
        if (el) el.textContent = seconds;
        if (seconds <= 0) {
            clearInterval(timer);
            window.location.href = 'https://platform.btpma.org/educate/';
        }
    }, 1000);
})();
</script>

<?php get_footer(); ?>
