<?php
/**
 * Template Name: Funnel — Start (Offer 0)
 * Slug: start
 *
 * Offer 0 entry page — Young Civic Engagement Challenge introduction,
 * value proposition, benefits, program structure, trust indicators.
 *
 * @package BT_Education_Ministry
 */

get_header();
?>

<!-- Progress Indicator -->
<div class="funnel-progress" role="navigation" aria-label="Funnel progress">
    <div class="container">
        <ol class="funnel-progress__steps">
            <li class="funnel-progress__step is-active" aria-current="step"><span>1</span> Discover</li>
            <li class="funnel-progress__step"><span>2</span> Learn</li>
            <li class="funnel-progress__step"><span>3</span> Sign Up</li>
            <li class="funnel-progress__step"><span>4</span> Welcome</li>
        </ol>
    </div>
</div>

<!-- ============================
     HERO
     ============================ -->
<section class="hero hero--home" aria-labelledby="start-hero-heading">
    <div class="container">
        <div class="grid grid--6-6" style="align-items:center;">
            <div class="hero__content">
                <span class="hero__subtitle">Young Civic Engagement Challenge</span>
                <h1 id="start-hero-heading" class="hero__title">Take the Challenge.<br><span class="text-gold">Shape Your Community.</span></h1>
                <p class="hero__text">Join a free civic education program designed for emerging leaders. Learn how government, law, finance, and community systems work — and how you can make a real impact.</p>
                <div class="btn-group">
                    <a href="<?php echo esc_url( home_url( '/learn/' ) ); ?>" class="btn btn--primary btn--lg" data-aemp-cta="begin_journey">Begin Your Journey</a>
                    <a href="#what-youll-learn" class="btn btn--outline-light btn--lg">See What You'll Learn</a>
                </div>
            </div>
            <div class="hero__image">
                <img src="https://cdn.abacus.ai/images/3b7a03dd-9252-4fb2-ad1f-9c0cf85d05dd.png"
                     alt="Young person studying civic education material late at night"
                     width="600" height="400" loading="eager">
            </div>
        </div>
    </div>
</section>

<!-- ============================
     TRUST BAR
     ============================ -->
<?php get_template_part( 'template-parts/content', 'trust-bar' ); ?>

<!-- ============================
     VALUE PROPOSITION
     ============================ -->
<section class="section" aria-labelledby="value-heading">
    <div class="container">
        <div class="section__header">
            <span class="section__subtitle">Why Join</span>
            <h2 id="value-heading">100% Free. Real Impact. Zero Risk.</h2>
            <p>This challenge is funded through our 508(c)(1)(a) nonprofit ministry. No fees, no hidden costs — just structured education for families who need it.</p>
        </div>

        <div class="grid grid--3">
            <div class="card card--program">
                <div class="card__icon">🎓</div>
                <h4 class="card__title">Free Entry</h4>
                <p class="card__text">No tuition, no materials cost. Everything you need is provided through our secure learning platform.</p>
            </div>
            <div class="card card--program">
                <div class="card__icon">🏛️</div>
                <h4 class="card__title">Civic Education</h4>
                <p class="card__text">Understand the systems — government, law, finance — that shape your community and your future.</p>
            </div>
            <div class="card card--program">
                <div class="card__icon">🌍</div>
                <h4 class="card__title">Community Impact</h4>
                <p class="card__text">Apply what you learn to real community challenges and build leadership skills that last a lifetime.</p>
            </div>
        </div>
    </div>
</section>

<!-- ============================
     WHAT YOU'LL LEARN
     ============================ -->
<section class="section section--light" id="what-youll-learn" aria-labelledby="learn-heading">
    <div class="container">
        <div class="section__header">
            <span class="section__subtitle">Curriculum Highlights</span>
            <h2 id="learn-heading">What You'll Learn</h2>
        </div>

        <div class="grid grid--4">
            <div class="card">
                <div class="card__icon">📜</div>
                <h4 class="card__title">Constitutional Literacy</h4>
                <p class="card__text">Understand your rights, responsibilities, and how the Constitution shapes everyday life.</p>
            </div>
            <div class="card">
                <div class="card__icon">💰</div>
                <h4 class="card__title">Financial Foundations</h4>
                <p class="card__text">Learn budgeting, saving, credit, and the basics of generational wealth-building.</p>
            </div>
            <div class="card">
                <div class="card__icon">🤝</div>
                <h4 class="card__title">Community Leadership</h4>
                <p class="card__text">Develop the skills to organize, lead, and serve your community with integrity.</p>
            </div>
            <div class="card">
                <div class="card__icon">📖</div>
                <h4 class="card__title">Scripture-Based Ethics</h4>
                <p class="card__text">Ground your leadership in faith-based principles of stewardship and service.</p>
            </div>
        </div>
    </div>
</section>

<!-- ============================
     PROGRAM STRUCTURE
     ============================ -->
<section class="section" aria-labelledby="structure-heading">
    <div class="container">
        <div class="grid grid--6-6" style="align-items:center;">
            <div>
                <span class="section__subtitle">How It Works</span>
                <h2 id="structure-heading">Program Structure</h2>
                <p>The challenge is self-paced and delivered through our secure learning management system. Complete modules, earn progress, and unlock the next level.</p>

                <div class="funnel-timeline">
                    <div class="funnel-timeline__item">
                        <div class="funnel-timeline__marker">1</div>
                        <div>
                            <h5>Sign Up</h5>
                            <p>Create your free Seeker-level account in under 2 minutes.</p>
                        </div>
                    </div>
                    <div class="funnel-timeline__item">
                        <div class="funnel-timeline__marker">2</div>
                        <div>
                            <h5>Learn</h5>
                            <p>Access structured modules on civic literacy, finance, and leadership.</p>
                        </div>
                    </div>
                    <div class="funnel-timeline__item">
                        <div class="funnel-timeline__marker">3</div>
                        <div>
                            <h5>Apply</h5>
                            <p>Complete projects that make a real impact in your community.</p>
                        </div>
                    </div>
                    <div class="funnel-timeline__item">
                        <div class="funnel-timeline__marker">4</div>
                        <div>
                            <h5>Advance</h5>
                            <p>Progress through competency levels — Seeker → Operator → Architect → Steward.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div style="text-align:center;">
                <img src="https://cdn.abacus.ai/images/7003ae17-0f2e-4df9-bdda-c1786000e5ff.png"
                     alt="Competency ladder from Seeker to Steward"
                     width="500" height="400" loading="lazy"
                     style="border-radius:var(--radius-xl);">
            </div>
        </div>
    </div>
</section>

<!-- ============================
     TESTIMONIALS
     ============================ -->
<?php get_template_part( 'template-parts/content', 'testimonials' ); ?>

<!-- ============================
     FINAL CTA
     ============================ -->
<section class="section section--dark" aria-labelledby="start-final-cta">
    <div class="container text-center">
        <h2 id="start-final-cta" style="color:var(--color-white);">Ready to Begin?</h2>
        <p style="color:rgba(255,255,255,0.8);font-size:var(--text-body-lg);max-width:600px;margin:0 auto var(--space-xl);">The challenge is free, the education is real, and the impact is yours to create. Take the first step now.</p>
        <a href="<?php echo esc_url( home_url( '/learn/' ) ); ?>" class="btn btn--primary btn--lg" data-aemp-cta="begin_journey">Begin Your Journey</a>
    </div>
</section>

<?php get_footer(); ?>
