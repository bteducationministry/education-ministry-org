/**
 * BT Education Ministry — AEMP Analytics
 *
 * Sends page_view, cta_click and form_submit events to the AEMP measurement
 * endpoint.  Loaded on all funnel pages (and optionally site-wide).
 *
 * Endpoint : https://aemp-dashboard.btpma.org/measure
 * Payload  : { event, page_url, page_title, user_id, timestamp, meta }
 *
 * @package BT_Education_Ministry
 * @version 1.0.0
 */

(function () {
  'use strict';

  /* ------------------------------------------------------------------ */
  /*  Configuration                                                      */
  /* ------------------------------------------------------------------ */

  var ENDPOINT = 'https://aemp-dashboard.btpma.org/measure';

  // Map slugs → canonical event suffixes
  var PAGE_SLUGS = {
    '/start':     'start',
    '/start/':    'start',
    '/learn':     'learn',
    '/learn/':    'learn',
    '/signup':    'signup',
    '/signup/':   'signup',
    '/welcome':   'welcome',
    '/welcome/':  'welcome',
    '/capstone':  'capstone',
    '/capstone/': 'capstone',
    '/apply':     'apply',
    '/apply/':    'apply',
    '/book-call':  'book_call',
    '/book-call/': 'book_call'
  };

  /* ------------------------------------------------------------------ */
  /*  Helpers                                                            */
  /* ------------------------------------------------------------------ */

  /**
   * Return the slug key for the current path, or null.
   */
  function getPageSlug() {
    var path = window.location.pathname.replace(/\/+$/, '');
    if (!path) path = '/';
    return PAGE_SLUGS[path] || PAGE_SLUGS[path + '/'] || null;
  }

  /**
   * Get current user ID from localised WP data (btemData) or cookie, or 0.
   */
  function getUserId() {
    if (typeof btemData !== 'undefined' && btemData.userId) {
      return btemData.userId;
    }
    return 0;
  }

  /**
   * Generate an ISO-8601 timestamp string.
   */
  function isoNow() {
    return new Date().toISOString();
  }

  /**
   * Fire-and-forget beacon / fetch to the AEMP endpoint.
   *
   * @param {string}  eventName  e.g. "page_view_start"
   * @param {Object=} meta       optional extra key/value pairs
   */
  function sendEvent(eventName, meta) {
    var payload = {
      event:      eventName,
      page_url:   window.location.href,
      page_title: document.title,
      user_id:    getUserId(),
      timestamp:  isoNow(),
      event_type: eventName.split('_').slice(0, 2).join('_'), // e.g. page_view
      meta:       meta || {}
    };

    var json = JSON.stringify(payload);

    // Prefer sendBeacon (non-blocking), fall back to fetch
    if (navigator.sendBeacon) {
      try {
        navigator.sendBeacon(ENDPOINT, new Blob([json], { type: 'application/json' }));
        return;
      } catch (_) { /* fall through */ }
    }

    // Fallback: fetch (fire-and-forget)
    if (typeof fetch === 'function') {
      fetch(ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: json,
        keepalive: true
      }).catch(function () { /* silently fail */ });
    }
  }

  /* ------------------------------------------------------------------ */
  /*  1.  Page View Tracking                                             */
  /* ------------------------------------------------------------------ */

  var slug = getPageSlug();
  if (slug) {
    sendEvent('page_view_' + slug);
  }

  /* ------------------------------------------------------------------ */
  /*  2.  CTA Click Tracking                                             */
  /* ------------------------------------------------------------------ */

  // CTA mapping:  data-aemp-cta="begin_journey"  → cta_click_begin_journey
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-aemp-cta]');
    if (!btn) return;

    var ctaName = btn.getAttribute('data-aemp-cta');
    if (ctaName) {
      sendEvent('cta_click_' + ctaName, {
        cta_text: (btn.textContent || '').trim(),
        cta_href: btn.getAttribute('href') || ''
      });
    }
  });

  /* ------------------------------------------------------------------ */
  /*  3.  Form Submit Tracking                                           */
  /* ------------------------------------------------------------------ */

  // Listen for WPForms or native form submissions tagged with
  // data-aemp-form="offer0_signup" | "capstone_application" | "booking_request"
  //
  // WPForms fires a custom jQuery event: wpformsAjaxSubmitSuccess
  // We also hook the native submit event for non-AJAX forms.

  function trackFormSubmit(formEl) {
    if (!formEl) return;
    var eventSuffix = formEl.getAttribute('data-aemp-form');
    if (!eventSuffix) {
      // Try parent wrapper
      var wrapper = formEl.closest('[data-aemp-form]');
      if (wrapper) eventSuffix = wrapper.getAttribute('data-aemp-form');
    }
    if (eventSuffix) {
      sendEvent('form_submit_' + eventSuffix);
    }
  }

  // Native form submit
  document.addEventListener('submit', function (e) {
    trackFormSubmit(e.target);
  });

  // WPForms AJAX success (jQuery event)
  if (typeof jQuery !== 'undefined') {
    jQuery(document).on('wpformsAjaxSubmitSuccess', function (_e, response) {
      // response.data.$form is a jQuery object of the form
      if (response && response.data && response.data.$form) {
        trackFormSubmit(response.data.$form[0] || response.data.$form);
      }
    });
  }

  /* ------------------------------------------------------------------ */
  /*  Public API (optional): window.btemAnalytics.send(name, meta)       */
  /* ------------------------------------------------------------------ */

  window.btemAnalytics = { send: sendEvent };

})();
