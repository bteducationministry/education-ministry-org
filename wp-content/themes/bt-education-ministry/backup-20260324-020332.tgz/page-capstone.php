<?php
/**
 * Template Name: Funnel — Capstone (Estate Trust Directive)
 * Slug: capstone
 *
 * Estate Trust Directive overview page — $55k capstone engagement.
 * Trust diagram, value proposition, qualification criteria, FAQ.
 *
 * @package BT_Education_Ministry
 */

get_header();
?>

<!-- ============================
     HERO
     ============================ -->
<section class="hero hero--home" aria-labelledby="capstone-hero-heading">
    <div class="container">
        <div class="grid grid--6-6" style="align-items:center;">
            <div class="hero__content">
                <span class="hero__subtitle">Capstone Engagement</span>
                <h1 id="capstone-hero-heading" class="hero__title">Estate Trust<br><span class="text-gold">Directive</span></h1>
                <p class="hero__text">The ultimate private engagement for qualified families seeking full life-cycle estate trust planning, fiduciary structuring, and multi-generational governance architecture.</p>
                <div class="btn-group">
                    <a href="<?php echo esc_url( home_url( '/apply/' ) ); ?>" class="btn btn--primary btn--lg" data-aemp-cta="apply_capstone">Apply for Capstone Services</a>
                    <a href="#whats-included" class="btn btn--outline-light btn--lg">What’s Included</a>
                </div>
            </div>
            <div class="hero__image">
                <img src="https://cdn.abacus.ai/images/ac57de4b-7b7b-4a41-a0c6-2f015eeb91b3.png"
                     alt="Estate Trust Directive gold emblem representing multi-generational trust structuring"
                     width="500" height="500" loading="eager"
                     style="border-radius:var(--radius-xl);">
            </div>
        </div>
    </div>
</section>

<!-- ============================
     TRUST DIAGRAM / OVERVIEW
     ============================ -->
<section class="section" aria-labelledby="overview-heading">
    <div class="container">
        <div class="section__header">
            <span class="section__subtitle">Overview</span>
            <h2 id="overview-heading">What Is the Estate Trust Directive?</h2>
            <p>A comprehensive, end-to-end engagement that architects your family’s legacy through legally informed trust design, treasury alignment, healthcare directives, and governance frameworks.</p>
        </div>

        <!-- Trust Structure Visualization -->
        <div class="capstone-trust-diagram">
            <div class="capstone-trust-diagram__center">
                <div class="capstone-trust-diagram__node capstone-trust-diagram__node--main">
                    <span>⚖️</span>
                    <strong>Estate Trust Directive</strong>
                </div>
            </div>
            <div class="grid grid--3" style="margin-top:var(--space-xl);">
                <div class="card text-center">
                    <div style="font-size:32px;margin-bottom:var(--space-sm);">🏦</div>
                    <h4 class="card__title">Trust Design</h4>
                    <p class="card__text">Custom trust architecture tailored to your family’s asset profile and goals.</p>
                </div>
                <div class="card text-center">
                    <div style="font-size:32px;margin-bottom:var(--space-sm);">📊</div>
                    <h4 class="card__title">Treasury Alignment</h4>
                    <p class="card__text">Strategic alignment of financial assets, accounts, and revenue streams.</p>
                </div>
                <div class="card text-center">
                    <div style="font-size:32px;margin-bottom:var(--space-sm);">📝</div>
                    <h4 class="card__title">Governance Framework</h4>
                    <p class="card__text">Rules, bylaws, and decision-making structures for multi-generational stewardship.</p>
                </div>
            </div>
            <div class="grid grid--3" style="margin-top:var(--grid-gutter);">
                <div class="card text-center">
                    <div style="font-size:32px;margin-bottom:var(--space-sm);">🏥</div>
                    <h4 class="card__title">Healthcare Directives</h4>
                    <p class="card__text">Medical power of attorney, living wills, and healthcare decision frameworks.</p>
                </div>
                <div class="card text-center">
                    <div style="font-size:32px;margin-bottom:var(--space-sm);">👨‍👩‍👧‍👦</div>
                    <h4 class="card__title">Beneficiary Design</h4>
                    <p class="card__text">Structured beneficiary tiers, succession planning, and inheritance frameworks.</p>
                </div>
                <div class="card text-center">
                    <div style="font-size:32px;margin-bottom:var(--space-sm);">🛡️</div>
                    <h4 class="card__title">Fiduciary Structuring</h4>
                    <p class="card__text">Define roles, responsibilities, and accountability for trustees and fiduciaries.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ============================
     VALUE PROPOSITION — $55k
     ============================ -->
<section class="section section--light" id="whats-included" aria-labelledby="value-heading">
    <div class="container">
        <div class="capstone-block">
            <div class="grid grid--6-6" style="align-items:center;">
                <div>
                    <span class="section__subtitle" style="color:var(--color-gold);">Investment</span>
                    <h3>$55,000 Capstone Engagement</h3>
                    <p style="color:rgba(255,255,255,0.85);font-size:var(--text-body-lg);">A one-time investment in your family’s multi-generational legacy. Every component is tailored to your unique family structure.</p>
                    <div class="card__price">$55,000</div>
                </div>
                <div>
                    <ul class="funnel-checklist funnel-checklist--light">
                        <li>Full estate trust design &amp; documentation</li>
                        <li>Treasury alignment &amp; asset mapping</li>
                        <li>Healthcare directives &amp; medical POA</li>
                        <li>Custom governance architecture</li>
                        <li>Beneficiary design &amp; succession planning</li>
                        <li>Fiduciary structuring &amp; role definition</li>
                        <li>12 months of advisory support</li>
                        <li>Head Steward AI premium access</li>
                        <li>Private consultation sessions (up to 10)</li>
                        <li>Complete documentation package</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ============================
     MULTI-GENERATIONAL BENEFITS
     ============================ -->
<section class="section" aria-labelledby="benefits-heading">
    <div class="container">
        <div class="section__header">
            <span class="section__subtitle">Legacy</span>
            <h2 id="benefits-heading">Multi-Generational Planning Benefits</h2>
        </div>

        <div class="impact-split">
            <div class="impact-split__before">
                <h3>Without a Trust Directive</h3>
                <ul class="funnel-checklist funnel-checklist--negative">
                    <li>Assets exposed to probate &amp; legal fees</li>
                    <li>No structured succession plan</li>
                    <li>Family disputes over inheritance</li>
                    <li>Healthcare decisions left to courts</li>
                    <li>Wealth eroded within 1–2 generations</li>
                </ul>
            </div>
            <div class="impact-split__after">
                <h3 style="color:var(--color-gold);">With Estate Trust Directive</h3>
                <ul class="funnel-checklist funnel-checklist--light">
                    <li>Assets protected in perpetuity</li>
                    <li>Clear governance &amp; succession</li>
                    <li>Family alignment &amp; unity</li>
                    <li>Healthcare wishes documented &amp; honored</li>
                    <li>Wealth preserved for 3+ generations</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- ============================
     QUALIFICATION CRITERIA
     ============================ -->
<section class="section section--light" aria-labelledby="qualify-heading">
    <div class="container">
        <div class="section__header">
            <span class="section__subtitle">Qualification</span>
            <h2 id="qualify-heading">Who Qualifies?</h2>
            <p>The Estate Trust Directive is designed for families with established assets and a genuine commitment to multi-generational stewardship.</p>
        </div>

        <div class="grid grid--3">
            <div class="card">
                <div class="card__icon">💰</div>
                <h4 class="card__title">Minimum Asset Threshold</h4>
                <p class="card__text">Families with combined assets (real estate, investments, business equity) of $500,000 or more are ideal candidates.</p>
            </div>
            <div class="card">
                <div class="card__icon">👨‍👩‍👧‍👦</div>
                <h4 class="card__title">Family Structure</h4>
                <p class="card__text">Multi-generational families with 2+ beneficiaries and a desire to create formal governance structures.</p>
            </div>
            <div class="card">
                <div class="card__icon">🏛️</div>
                <h4 class="card__title">Governance Readiness</h4>
                <p class="card__text">Willingness to engage in a structured process, attend consultations, and implement the designed framework.</p>
            </div>
        </div>
    </div>
</section>

<!-- ============================
     FAQ
     ============================ -->
<section class="section" aria-labelledby="faq-heading">
    <div class="container container--narrow">
        <div class="section__header">
            <span class="section__subtitle">Questions</span>
            <h2 id="faq-heading">Frequently Asked Questions</h2>
        </div>

        <div class="funnel-faq">
            <details class="funnel-faq__item">
                <summary class="funnel-faq__question">What is the Estate Trust Directive?</summary>
                <div class="funnel-faq__answer">
                    <p>It’s a comprehensive, end-to-end engagement that designs your family’s trust architecture, governance framework, healthcare directives, and fiduciary structure — all tailored to your unique situation.</p>
                </div>
            </details>

            <details class="funnel-faq__item">
                <summary class="funnel-faq__question">Why does it cost $55,000?</summary>
                <div class="funnel-faq__answer">
                    <p>This is a premium, fully custom engagement that includes up to 10 private consultation sessions, complete documentation, 12 months of advisory support, and access to specialized AI tools. The value far exceeds the investment when compared to piecemeal legal and financial planning services.</p>
                </div>
            </details>

            <details class="funnel-faq__item">
                <summary class="funnel-faq__question">How long does the process take?</summary>
                <div class="funnel-faq__answer">
                    <p>Most engagements are completed within 3–6 months, depending on family complexity and scheduling. The 12-month advisory support continues after the core engagement.</p>
                </div>
            </details>

            <details class="funnel-faq__item">
                <summary class="funnel-faq__question">Do I need to be a current member?</summary>
                <div class="funnel-faq__answer">
                    <p>While not strictly required, preference is given to families who have progressed through the Steward membership tier, as they have foundational knowledge of governance principles.</p>
                </div>
            </details>

            <details class="funnel-faq__item">
                <summary class="funnel-faq__question">What happens after I apply?</summary>
                <div class="funnel-faq__answer">
                    <p>Your application is reviewed within 3–5 business days. If qualified, you’ll be invited to schedule a complimentary consultation to discuss your family’s specific needs.</p>
                </div>
            </details>

            <details class="funnel-faq__item">
                <summary class="funnel-faq__question">Is this legal advice?</summary>
                <div class="funnel-faq__answer">
                    <p>BT Education Ministry provides educational guidance on trust structuring and governance. We recommend working with a licensed attorney for legal execution of any documents. We can coordinate with your legal team as part of the engagement.</p>
                </div>
            </details>
        </div>
    </div>
</section>

<!-- ============================
     FINAL CTA
     ============================ -->
<section class="section section--dark" aria-labelledby="capstone-final-cta">
    <div class="container text-center">
        <h2 id="capstone-final-cta" style="color:var(--color-white);">Ready to Secure Your Family’s Legacy?</h2>
        <p style="color:rgba(255,255,255,0.8);font-size:var(--text-body-lg);max-width:600px;margin:0 auto var(--space-xl);">Apply now to see if you qualify for the Estate Trust Directive. The application takes about 10 minutes.</p>
        <a href="<?php echo esc_url( home_url( '/apply/' ) ); ?>" class="btn btn--primary btn--lg" data-aemp-cta="apply_capstone">Apply for Capstone Services</a>
    </div>
</section>

<?php get_footer(); ?>
